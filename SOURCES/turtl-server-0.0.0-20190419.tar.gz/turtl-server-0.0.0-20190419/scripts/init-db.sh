#!/bin/bash

node tools/create-db-schema.js

