#![recursion_limit="128"]

fn main() {
    println!("Hello, world!");
}
