//! Turtl's internationalization library.

// stub this out for now.
#[macro_export]
macro_rules! t {
    ($label:expr) => {
        $label
    }
}

