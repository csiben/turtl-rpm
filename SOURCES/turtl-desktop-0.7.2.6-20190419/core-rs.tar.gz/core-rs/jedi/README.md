# Jedi

Working with JSON in Rust is kind of a pain (or so, I thought, anyway). This
library attempts to ease that pain a bit.

It provides a set of functions for getting data out of (Serde) JSON objects.
There's not a whole lot else to say.

