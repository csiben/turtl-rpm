# Config

A simple wrapper around Turtl's core-rs `jedi` project to allow a global config
object with some nice getters/setters for it.

