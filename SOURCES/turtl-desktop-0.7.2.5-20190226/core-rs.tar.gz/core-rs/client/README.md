# Turtl client

A simple client/"UI" for Turtl's core-rs. This is basically a shitty REPL that
lets you test commands against the core. Good as a reference/testbes for
implementing a real UI around the core.

