var NOTE_COLORS = ['none', 'blue', 'red', 'green', 'purple', 'pink', 'brown', 'black'];
var NOTE_DEFAULT_SORT = ['created', 'desc'];

